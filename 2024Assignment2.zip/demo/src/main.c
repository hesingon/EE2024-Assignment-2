/*****************************************************************************
 *   A demo example using several of the peripherals on the base board
 *
 *   Copyright(C) 2011, EE2024
 *   All rights reserved.
 *
 ******************************************************************************/

#include "lpc17xx_pinsel.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_ssp.h"
#include "lpc17xx_timer.h"

#include <stdio.h>

#include "led7seg.h"
#include "acc.h"
#include "oled.h"
#include "rgb.h"
#include "light.h"
#include "temp.h"

volatile uint32_t msTicks; // counter for 1ms SysTicks

int32_t xoff = 0;
int32_t yoff = 0;
int32_t zoff = 0;

int8_t x = 0;
int8_t y = 0;
int8_t z = 0;

// ****************
//  SysTick_Handler - just increment SysTick counter
void SysTick_Handler(void) {
    msTicks++;
}

static void init_ssp(void)
{
    SSP_CFG_Type SSP_ConfigStruct;
    PINSEL_CFG_Type PinCfg;

    /*
     * Initialize SPI pin connect
     * P0.7 - SCK;
     * P0.8 - MISO
     * P0.9 - MOSI
     * P2.2 - SSEL - used as GPIO
     */
    PinCfg.Funcnum = 2;
    PinCfg.OpenDrain = 0;
    PinCfg.Pinmode = 0;
    PinCfg.Portnum = 0;
    PinCfg.Pinnum = 7;
    PINSEL_ConfigPin(&PinCfg);
    PinCfg.Pinnum = 8;
    PINSEL_ConfigPin(&PinCfg);
    PinCfg.Pinnum = 9;
    PINSEL_ConfigPin(&PinCfg);
    PinCfg.Funcnum = 0;
    PinCfg.Portnum = 2;
    PinCfg.Pinnum = 2;
    PINSEL_ConfigPin(&PinCfg);

    SSP_ConfigStructInit(&SSP_ConfigStruct);

    // Initialize SSP peripheral with parameter given in structure above
    SSP_Init(LPC_SSP1, &SSP_ConfigStruct);

    // Enable SSP peripheral
    SSP_Cmd(LPC_SSP1, ENABLE);

}

static void init_i2c(void)
{
    PINSEL_CFG_Type PinCfg;

    /* Initialize I2C2 pin connect */
    PinCfg.Funcnum = 2;
    PinCfg.Pinnum = 10;
    PinCfg.Portnum = 0;
    PINSEL_ConfigPin(&PinCfg);
    PinCfg.Pinnum = 11;
    PINSEL_ConfigPin(&PinCfg);

    // Initialize I2C peripheral
    I2C_Init(LPC_I2C2, 100000);

    /* Enable I2C1 operation */
    I2C_Cmd(LPC_I2C2, ENABLE);
}

static void init_GPIO(void)
{
    // Initialize button
    PINSEL_CFG_Type PinCfg;
    PinCfg.Funcnum = 0;
    PinCfg.OpenDrain = 0;
    PinCfg.Pinmode = 0;
    PinCfg.Portnum = 1;
    PinCfg.Pinnum = 31;
    PINSEL_ConfigPin(&PinCfg);
    PinCfg.Portnum = 0;
    PinCfg.Pinnum = 4;
    PINSEL_ConfigPin(&PinCfg);
    PinCfg.Pinnum = 2;
    PINSEL_ConfigPin(&PinCfg);

    //<---- Speaker ------>
    /*
    GPIO_SetDir(2, 1<<0, 1);
    GPIO_SetDir(2, 1<<1, 1);

    GPIO_SetDir(0, 1<<27, 1);
    GPIO_SetDir(0, 1<<28, 1);
    GPIO_SetDir(2, 1<<13, 1);
    GPIO_SetDir(0, 1<<26, 1);

    GPIO_ClearValue(0, 1<<27); //LM4811-clk
    GPIO_ClearValue(0, 1<<28); //LM4811-up/dn
    GPIO_ClearValue(2, 1<<13); //LM4811-shutdn
	*/
    //<---- Speaker ------>
}

static uint32_t getTicks()
{
    return msTicks;
}

static void init_all()
{
	init_i2c();
	init_ssp();
	init_GPIO();

	rgb_init();
	acc_init();
	light_enable();
	oled_init();
	led7seg_init();
	temp_init(&getTicks);
}

void acc_setup()
{
    /*
     * Assume base board in zero-g position when reading first value.
     */
	acc_read(&x, &y, &z);
	xoff = 0-x;
	yoff = 0-y;
	zoff = 64-z;
}

int main (void) {

    uint8_t ch = 0;
    uint8_t rgbNum = 4;
    uint8_t rgbTogg = 0;

    uint32_t currTime = getTicks();

    int lightReading;
    int tempReading;

    uint32_t ch7seg[] = {
            48, // 0
            49, // 1
            50, // 2
            51, // 3
            52, // 4
            53, // 5
            54, // 6
            55, // 7
            56, // 8
            57, // 9
            65, // A
            66, // B
            67, // C
            68, // D
            69, // E
            70, // F
    };


//sysTick
    if (SysTick_Config(SystemCoreClock / 1000)) {
        while (1);  // Capture error
    }

    init_all();

    acc_setup();

    oled_clearScreen(OLED_COLOR_WHITE);

    while (1)
    {

        //conditions
        if (ch==16) ch=0; //char rollover, 7seg

        if(rgbNum>=0x06) rgbNum=4; //RGB rollover, red LED

        if(rgbTogg>=2) rgbTogg=0; //RGB toggle

        if((getTicks()-currTime)>1000)
        {
            //temp sensor
            char temp_sensor_value[40];
            tempReading=temp_read();
            printf("temp: %u\n", tempReading);
            sprintf(temp_sensor_value,"Temp: %d",tempReading);

            //accelerometer
            char acc_sensor_value[40];
            acc_read(&x, &y, &z);
            x = x+xoff;
            y = y+yoff;
            z = z+zoff;
            printf("acc: x:%d y:%d z:%d \n", x, y, z);
            sprintf(acc_sensor_value,"Acc: x:%d y:%d z:%d", x, y, z);

            //light sensor
            char light_sensor_val[40];
            lightReading = light_read();
            printf("light: %u\n", lightReading);
            sprintf(light_sensor_val, "Light: %d" , lightReading);

            //7seg
            led7seg_setChar(ch7seg[ch++], FALSE);

            //RGB
            if (rgbTogg==0)
            {
                rgb_setLeds(rgbNum++);
            }
            rgbTogg++;


            //Display info on oLED, on '5' 'A' 'F'
            if((ch==6)||(ch==11)||ch==16)
            {
                oled_putString(1,1,(uint8_t *)temp_sensor_value,OLED_COLOR_BLACK,OLED_COLOR_WHITE);
                oled_putString(1,9,(uint8_t *)light_sensor_val,OLED_COLOR_BLACK,OLED_COLOR_WHITE);
                oled_putString(1,17,(uint8_t *)acc_sensor_value,OLED_COLOR_BLACK,OLED_COLOR_WHITE);
            }

            //reconfig currTime
            currTime=getTicks();
        }

        Timer0_Wait(1);
    }


}

void check_failed(uint8_t *file, uint32_t line)
{
    /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

    /* Infinite loop */
    while(1);
}
